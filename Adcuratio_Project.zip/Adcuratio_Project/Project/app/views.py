from django.shortcuts import render
from django.http import HttpResponse
from app.forms import MovieForm
from app.models import Movie
from django.contrib.auth.decorators import login_required
# Create your views here.
@login_required(login_url='/login/')
def MovieVW(request):
    form=MovieForm()
    if request.method == 'POST' and request.FILES:
        form=MovieForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse('data has been stored')
    return render(request,'movie.html',{'form':form})

@login_required(login_url='/login/')
def MovieRead(request):
    queryset=Movie.objects.all()
    
    return render(request,'read.html',{'queryset':queryset})
    
@login_required(login_url='/login/')
def MovieUpdate(request,pk):
    queryset=Movie.objects.get(id=pk)
    form=MovieForm(instance=queryset)
    if request.method == 'POST' and request.FILES:
        form=MovieForm(request.POST,request.FILES,instance=queryset)
        if form.is_valid():
            form.save()
            return HttpResponse('data has been stored')
    return render(request,'update.html',{'form':form})


'''
step for media files
step1:-  create folder with name 'media' in project container

in settings.py
    MEDIA_URL='media/'

    MEDIA_ROOT=BASE_DIR/'media'

in models.py
    image=models.ImageField(upload_to='movie')
        upload_to attribute will create sub folder in media folder to segregate media files
in html page
    
    <form method="post" enctype="multipart/form-data">
in views.py
     if request.method == 'POST' and request.FILES:
        form=MovieForm(request.POST,request.FILES)
        if form.is_valid():
in urls.py
    from django.conf.urls.static import static
    from django.conf import settings


    urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
'''