from django.db import models

LANG_CHIOCES=[['Kannada','Kannada'],['English','English'],['Telugu','Telugu'],['Tamil','Tamil'],['Hindi','Hindi']]
# Create your models here.
class Movie(models.Model):
    name=models.CharField(max_length=40)
    language=models.CharField(max_length=30,choices=LANG_CHIOCES)
    Release_date=models.DateField(auto_now_add=True)
    director=models.CharField(max_length=40)
    image=models.ImageField(upload_to='movie')
    

    def __str__(self):
        return self.name