from django.shortcuts import render
from django.http import HttpResponse
from registerapp.forms import RegisterForm
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import  AuthenticationForm
# Create your views here.

def RegisterVW(request):
    form=RegisterForm()
    if request.method=='POST':
        form=RegisterForm(request.POST)
        if form.is_valid():
            form=form.save(commit=False)
            password=form.password
            form.password=make_password(password)
            form.save()
            return HttpResponse('data has been stored')

    return render(request,'register.html',{'form':form})


def LoginVW(request):
    form=AuthenticationForm()
    if request.method =='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return HttpResponse('successfully loged in ')
    return render(request,'login.html',{'form':form})


@login_required(login_url='/login/')
def LogoutVW(request):
    logout(request)
    return HttpResponse('successfully loged out')