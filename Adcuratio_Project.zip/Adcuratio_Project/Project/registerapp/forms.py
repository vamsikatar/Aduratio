from django import forms
from registerapp.models import RegisterModel

class RegisterForm(forms.ModelForm):
    password_again=forms.CharField(widget=forms.PasswordInput())
    class Meta:
        model=RegisterModel
        fields=['username','first_name','last_name','email','mobile','gender','password','password_again']
        widgets={
            'gender':forms.RadioSelect(),
            'password':forms.PasswordInput()
        }
    def clean(self):
        password=self.cleaned_data['password']
        password_again=self.cleaned_data['password_again']
        if password != password_again:
            raise forms.ValidationError('password should be same as password again')